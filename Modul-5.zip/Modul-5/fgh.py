from asd import Manusia
class Mahasiswa(Manusia):
    """Class Mahasiswa yang dibangun darii class Manusia"""
    def __init__(self,nama,NIM,kota,us):
        self.nama=nama
        self.NIM=NIM
        self.kota=kota
        self.uang=us
    def __str__(self):
        s=self.nama+',NIM '+str(self.NIM)\
           +'. live in '+self.kota\
           +'. money pocket Rp '+str(self.uang)\
           +'. every month'
        return s
    def ambilNama(self):
        return self.nama
    def ambilNIM(self):
        return self.NIM
    def ambilUang(self):
        return self.uang
    def makan(self,s):
        print ("I'm just ate",s,"while studying")
        self.keadaan='Satisfied'
    def ambilKota(self):
        return self.kota
    def perbaruiKota(self,k):
        self.kota=k
    def tambahUang(self,n):
        self.uang+=n
